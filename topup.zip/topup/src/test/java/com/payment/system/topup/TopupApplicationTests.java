package com.payment.system.topup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopupApplicationTests {

	@Test
	void contextLoads() {
	}

}
