package com.payment.system.topup.Entity;

public enum TransactionType {
	
	TOPUP,DEDUCT

}
