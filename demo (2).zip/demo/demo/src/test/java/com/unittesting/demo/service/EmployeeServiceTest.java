package com.unittesting.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unittesting.demo.entity.Employee;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unittesting.demo.DemoApplication;
import com.unittesting.demo.dto.EmployeeDTO;
import com.unittesting.demo.service.EmployeeService;

@SpringBootTest(classes = DemoApplication.class)
@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTest {

    @InjectMocks
    private EmployeeService employeeService;

    private EmployeeDTO employeeDTO;

    @BeforeEach
    void setUp() {

        MockitoAnnotations.openMocks(this);

        final ModelMapper modelMapper = new ModelMapper();
        employeeService = new EmployeeService(modelMapper);

        // Initialize the EmployeeDTO with sample data
        employeeDTO = new EmployeeDTO();
        employeeDTO.setId("1");
        employeeDTO.setName("John");
        employeeDTO.setPhone(1234567890L);
        employeeDTO.setRole("Engineer");
        employeeDTO.setSalary(5000.00);
    }

    @Test
    public void createEmployeeTest(){

        //ModelMapper modelMapper = Mockito.mock(ModelMapper.class);
        // Create a mock Employee entity that the service will map to
        Employee mockEmployee = new Employee();
        mockEmployee.setId(employeeDTO.getId());
        mockEmployee.setName(employeeDTO.getName() + "MyName");
        mockEmployee.setPhone(employeeDTO.getPhone());
        mockEmployee.setRole(employeeDTO.getRole() + "MyRole");
        mockEmployee.setSalary(employeeDTO.getSalary());
        mockEmployee.setExtraValue("Extra Value");

        // Mock the mapping from Employee entity to EmployeeDTO
        EmployeeDTO expectedDTO = new EmployeeDTO();
        expectedDTO.setId(employeeDTO.getId());
        expectedDTO.setName("JohnMyName");
        expectedDTO.setPhone(employeeDTO.getPhone());
        expectedDTO.setRole("EngineerMyRole");
        expectedDTO.setSalary(employeeDTO.getSalary());

        // Verify that the ModelMapper's map method was called with the correct arguments
        //verify(modelMapper, times(1)).map(any(Employee.class), any(EmployeeDTO.class));

        // Call the service method
        EmployeeDTO result = employeeService.createEmployee(employeeDTO);

        // Assertions
        assertEquals(expectedDTO.getId(), result.getId());
        assertEquals(expectedDTO.getName(), result.getName());
        assertEquals(expectedDTO.getRole(), result.getRole());
        assertEquals(expectedDTO.getPhone(), result.getPhone());
        assertEquals(expectedDTO.getSalary(), result.getSalary());

    }

}
