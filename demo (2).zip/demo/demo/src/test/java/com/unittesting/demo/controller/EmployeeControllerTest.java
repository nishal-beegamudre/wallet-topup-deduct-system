package com.unittesting.demo.controller;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unittesting.demo.DemoApplication;
import com.unittesting.demo.dto.EmployeeDTO;
import com.unittesting.demo.service.EmployeeService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = DemoApplication.class)
public class EmployeeControllerTest {
	
	Logger logger = LoggerFactory.getLogger(EmployeeControllerTest.class);

	private MockMvc mockMvc;
	
	@Mock
	public EmployeeService employeeService;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	
	EmployeeDTO serviceRequestDTO;
	EmployeeDTO responseDTO;
	EmployeeDTO controllerRequestDTO;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		
		ObjectMapper objectMapper1 = new ObjectMapper();
		
		EmployeeController employeeController = new EmployeeController(employeeService,objectMapper1);
		
		mockMvc = MockMvcBuilders.standaloneSetup(employeeController).setControllerAdvice().build();

		
		responseDTO = new EmployeeDTO("1", "NishalMyName", 8762425910L, 78000.45,"ConsultantMyRole",null,null,null);
		controllerRequestDTO = new EmployeeDTO("1", "Nishal", 8762425910L, 78000.45,"Consultant",null,null,null);
		serviceRequestDTO = new EmployeeDTO("1", "Nishal", 8762425910L, 78000.45,"Consultant",null,null,null);
	}
	
	@Test
	public void createEmployeeTest() throws Exception {
		
		
		final EmployeeDTOMatcher matcher = new EmployeeDTOMatcher(serviceRequestDTO);
		
		when(employeeService.createEmployee(argThat(matcher)))
		.thenReturn(responseDTO);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("http://localhost:8085/createEmployee")
                .contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(controllerRequestDTO));
		
		mockMvc
		.perform(requestBuilder)
		.andExpect(status().isOk())
		.andExpect(MockMvcResultMatchers.content().json(objectMapper.writeValueAsString(responseDTO)));
                
		
	}
	
}
