package com.unittesting.demo.controller;

import org.mockito.ArgumentMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unittesting.demo.dto.EmployeeDTO;

public class EmployeeDTOMatcher implements ArgumentMatcher<EmployeeDTO> {

    private final EmployeeDTO expected;

    public EmployeeDTOMatcher(EmployeeDTO expected) {
        this.expected = expected;
    }

    @Override
    public boolean matches(EmployeeDTO argument) {
    	
        return expected.getId().equals(argument.getId())
            && expected.getName().equals(argument.getName())
            && expected.getPhone() == argument.getPhone()
            && expected.getSalary() == argument.getSalary()
            && expected.getRole().equals(argument.getRole());
    }

    @Override
    public String toString() {
    	return expected.toString();
    }
}

