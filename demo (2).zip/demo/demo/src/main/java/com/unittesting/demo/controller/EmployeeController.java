package com.unittesting.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.unittesting.demo.dto.EmployeeDTO;
import com.unittesting.demo.service.EmployeeService;

@RestController
public class EmployeeController {
	
	Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	//@Autowired
	private EmployeeService employeeService;
	
	//@Autowired
	private ObjectMapper objectMapper;
	
	public EmployeeController(EmployeeService employeeService,ObjectMapper objectMapper) {
		this.employeeService = employeeService;
		this.objectMapper = objectMapper;
	}
	
	@PostMapping("/createEmployee")
	public ResponseEntity<EmployeeDTO> createEmployee(@RequestBody EmployeeDTO employeeDTO) throws JsonProcessingException {
		
		EmployeeDTO response = employeeService.createEmployee(employeeDTO);
				
				logger.info("Response in main controller is "+objectMapper.writeValueAsString(response));
		
		return ResponseEntity.ok(response);
		
	}

}
