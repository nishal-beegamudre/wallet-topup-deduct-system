package com.unittesting.demo.entity;

import lombok.Builder;

@Builder
public class Employee {
	
	private String id;
	private String name;
	private long phone;
	private double salary;
	private String role;
	private String extraValue;
	
	public Employee(String id, String name, long phone, double salary, String role, String extraValue) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.salary = salary;
		this.role = role;
		this.extraValue = extraValue;
	}
	
	public Employee() {
		super();
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	public String getExtraValue() {
		return extraValue;
	}

	public void setExtraValue(String extraValue) {
		this.extraValue = extraValue;
	}

}

