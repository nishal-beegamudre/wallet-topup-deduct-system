package com.unittesting.demo.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unittesting.demo.dto.EmployeeDTO;
import com.unittesting.demo.entity.Employee;

@Service
public class EmployeeService {
	
	//@Autowired
	private final ModelMapper modelMapper;

	public EmployeeService(ModelMapper modelMapper){
		this.modelMapper = modelMapper;
	}
	
	public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
		System.out.println("DTO is "+employeeDTO.getId()+" "+employeeDTO.getName());

		Employee employee = new Employee();
		employee.setId(employeeDTO.getId());
		employee.setName(employeeDTO.getName()+"MyName");
		employee.setPhone(employeeDTO.getPhone());
		employee.setRole(employeeDTO.getRole()+"MyRole");
		employee.setSalary(employeeDTO.getSalary());
		employee.setExtraValue("Extra Value");

		System.out.println("Line 27");

		EmployeeDTO employeeDTOOutput = new EmployeeDTO();
				modelMapper.map(employee, employeeDTOOutput);
		System.out.println("Line 31");
				return employeeDTOOutput;
		
	}

}
