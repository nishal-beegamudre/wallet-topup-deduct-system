package com.unittesting.demo.dto;

import lombok.Builder;

@Builder
public class EmployeeDTO {
	
	private String id;
	private String name;
	private long phone;
	private double salary;
	private String role;
	//private String extraString;
	private Integer extraInteger;
	private Double extraDouble;
	private Long extraLong;
	

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	/*public String getExtraString() {
		return extraString;
	}

	public void setExtraString(String extraString) {
		this.extraString = extraString;
	}*/

	public Integer getExtraInteger() {
		return extraInteger;
	}

	public void setExtraInteger(Integer extraInteger) {
		this.extraInteger = extraInteger;
	}

	public Double getExtraDouble() {
		return extraDouble;
	}

	public void setExtraDouble(Double extraDouble) {
		this.extraDouble = extraDouble;
	}

	public Long getExtraLong() {
		return extraLong;
	}

	public void setExtraLong(Long extraLong) {
		this.extraLong = extraLong;
	}
	public EmployeeDTO(String id, String name, long phone, double salary, String role, /*String extraString,*/
			Integer extraInteger, Double extraDouble, Long extraLong) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.salary = salary;
		this.role = role;
		//this.extraString = extraString;
		this.extraInteger = extraInteger;
		this.extraDouble = extraDouble;
		this.extraLong = extraLong;
	}
	public EmployeeDTO() {
		super();
	}

}

